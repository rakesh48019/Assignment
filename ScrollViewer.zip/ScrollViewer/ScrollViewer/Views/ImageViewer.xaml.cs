﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ScrollViewer.ViewModel;

namespace ScrollViewer.Views
{
    /// <summary>
    /// Interaction logic for ImageViewer.xaml
    /// </summary>
    public partial class ImageViewer : UserControl
    {
        public ImageViewer()
        {
            var imageViewModel = new ImageViewVM();
            imageViewModel.UpdateImageInUi += UpdateUI;
            DataContext = imageViewModel;
            InitializeComponent();
        }

        public void UpdateUI(object obj, ImageSourceArgs imgArgs)
        {
            
            var imageObject = imgArgs.ImageObject;
            imageObject.Height = 300;
            imageObject.Width = 800;
            ImageCanvas.Children.Add(imageObject);
        }
    }
}
