﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ScrollViewer.ViewModel
{
    public class ImageSourceArgs:EventArgs
    {
        public Image ImageObject { get; }

        public ImageSourceArgs(Image imageObject)
        {
            ImageObject = imageObject;
        }

    }
}
