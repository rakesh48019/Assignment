﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using ImageReader;
using ScrollViewer.Commands;

namespace ScrollViewer.ViewModel
{
    public class ImageViewVM : INotifyPropertyChanged
    {
        private IPhysicalFile _physicalFile;
        private ICommand _nextCommand;
        private ICommand _exit;

        public EventHandler<ImageSourceArgs> UpdateImageInUi;


        public ICommand NextCommand
        {
            get { return _nextCommand; }
            set { _nextCommand = value; }
        }

        public ICommand Exit
        {
            get { return _exit; }
            set { _exit = value; }
        }

        public ImageViewVM()
        {
            _physicalFile = new PhysicalFile();
            _nextCommand = new ApplicationCommand(ExecuteNext, CanNextExecute);
            _exit = new ApplicationCommand(ExitCommandHandler, CanExitCommandHandler);

        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void ExecuteNext(object obj)
        {
            Image dynamicImage = new Image();
            using (var ms = (MemoryStream)_physicalFile.GetNextImageFromFile())
            {

                // Create a BitmapSource  
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.DecodePixelHeight = 125;
                bitmap.DecodePixelWidth = 125;
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = ms;
                bitmap.EndInit();

                // Set Image.Source  
                dynamicImage.Source = bitmap;
            }

            if (UpdateImageInUi != null)
            {
                var imageEventArg = new ImageSourceArgs(dynamicImage);
                UpdateImageInUi.Invoke(this, imageEventArg);
            }

        }

        private bool CanNextExecute(object param)
        {
            return true;
        }

        private void ExitCommandHandler(object obj)
        {
            _physicalFile.Dispose();
            Environment.Exit(0);
        }

        private bool CanExitCommandHandler(object param)
        {
            return true;
        }

    }
}
