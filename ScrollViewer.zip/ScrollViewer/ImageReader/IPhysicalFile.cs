﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageReader
{
    public interface IPhysicalFile : IDisposable
    {
        Stream GetNextImageFromFile();
    }
}