﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageReader
{
    /// <summary>
    /// 
    /// </summary>
    public class PhysicalFile : IPhysicalFile
    {
        //hard coding the file for the time being 
        //it will be best to pass the file path through constructor 
        private string _path = @"C:\Users\310284533\source\repos\ScrollViewer\ScrollViewer\ImageData\TestFile.bin";

        private MemoryStream _ms;
        private FileStream _fs;
        private const int HeaderSize = 1024;
        private int _totalSizeOfImage = 125 * 125 * 2;
        private long _totalFileSize;
        private int _currentFileLocation = 0;
        private bool _disposed = false;

        public PhysicalFile()
        {
            _fs = new FileStream(_path, FileMode.Open);
            _totalFileSize = _fs.Length;
            _fs.Seek(HeaderSize, SeekOrigin.Begin);
            _currentFileLocation = HeaderSize;
        }

        public Stream GetNextImageFromFile()
        {
            MemoryStream ms = new MemoryStream();
            byte[] buffer = new byte[_totalSizeOfImage];
            _fs.Read(buffer, 0, (int)_totalSizeOfImage);
            _currentFileLocation = _currentFileLocation + _totalSizeOfImage;
            ms.Write(buffer, 0, (int)_totalSizeOfImage);
            ms.Seek(0, SeekOrigin.Begin);
            return ms;
        }


        #region Idisposable interface implementation

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~PhysicalFile()
        {
            Dispose(true);
        }

        // Protected implementation of Dispose pattern.
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                // Dispose managed state (managed objects).

            }

            _fs.Close();
            _fs = null;
            _disposed = true;
        }


        #endregion

    }
}
